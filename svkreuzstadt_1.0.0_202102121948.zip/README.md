Sitepackage for the project "SVKreuzstadt"
==============================================================

Add some explanation here.
