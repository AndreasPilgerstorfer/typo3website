<?php

/**
 * Extension Manager/Repository config file for ext "svkreuzstadt".
 */
$EM_CONF[$_EXTKEY] = [
    'title' => 'SVKreuzstadt',
    'description' => '',
    'category' => 'templates',
    'constraints' => [
        'depends' => [
            'typo3' => '10.2.0-10.4.99',
            'fluid_styled_content' => '10.2.0-10.4.99',
            'rte_ckeditor' => '10.2.0-10.4.99',
        ],
        'conflicts' => [
        ],
    ],
    'autoload' => [
        'psr-4' => [
            'Fhooe\\Svkreuzstadt\\' => 'Classes',
        ],
    ],
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'author' => 'Andreas Pilgerstorfer',
    'author_email' => 'andreas.pilgi@gmail.com',
    'author_company' => 'FHOOE',
    'version' => '1.0.0',
];
